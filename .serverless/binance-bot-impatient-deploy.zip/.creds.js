module.exports = {
  key: "key",
  secret: "secret"
};
